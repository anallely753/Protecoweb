<p>De: <b><?php echo e($name); ?></b></p>
<p>Asunto: <b><?php echo e($subject); ?></b></p>
<p>Mensaje:</p>
<p><b><?php echo e($user_message); ?></b></p>
<p>Email: <b><?php echo e($email); ?></b></p>
<p>Bye :)</p>
<?php /**PATH C:\laragon\www\prueba2\resources\views/email.blade.php ENDPATH**/ ?>