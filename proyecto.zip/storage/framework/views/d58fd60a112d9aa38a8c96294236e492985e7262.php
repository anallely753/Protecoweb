
<?php $__env->startSection('content'); ?>
<main>
	<div class="jumbotron jumb-usr">
		<div class="container amarillo text-center pt-1 pt-md-4">
			<img src="<?php echo e(asset("img/users/$user->img")); ?>" alt="" class="show-user">
			<br><br>
			<h2><?php echo e($user->name); ?></h2>
			<h5><?php echo e($user->email); ?></h5>
			<br>	
			<form class="pb-1 pb-md-4" action="<?php echo e(route('usuariosimg.update', $user->id)); ?>" method="POST"enctype="multipart/form-data">
				<?php echo method_field('PATCH'); ?>			        	
				<?php echo csrf_field(); ?>
				<?php if($user->img==NULL): ?>
				<label for="img"><h5 class="center-text text-danger">Sube una foto de perfil</h5></label>
				<?php else: ?>
				<label for="img"><h5 class="center-text text-danger">Edita tu foto de perfil</h5></label>
				<?php endif; ?>
				<br>
				<input accept="image/*" type="file" name="img">
				<br>	
				<button type="submit" class="btn-primary">Subir Foto</button>
			</form>
		</div>
		
	</div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\prueba2\resources\views/usuarios/show.blade.php ENDPATH**/ ?>