
<?php $__env->startSection('content'); ?>
<main class="main_index mb-3 mb-md-5">
  <div class="card titulo bienvenidos">
  </div>
  <div class="container tareas tareas-admin">
    <div class="card text-black mb-2 tarea amarillo" >
      <div class="card-header">
        <h2 class="card-title d-inline "><?php echo e($tarea->titulo); ?></h2>
        <form action="<?php echo e(route('admintareas.destroy', $tarea->id)); ?>" method="POST" >
          <a href="<?php echo e(route('admintareas.show', $tarea->id)); ?>"><button type="button" class="btn btn-light float-right">Ver</button></a>
          <a href="<?php echo e(route('admintareas.edit', $tarea->id)); ?>"><button type="button" class="btn btn-light float-right">Editar</button></a>
          <?php echo csrf_field(); ?>
          <?php echo method_field('DELETE'); ?>
          <a><button type="submit" class="btn btn-light float-right">Eliminar</button></a>
        </form>
        <h6 >Fecha de Entrega: <b><?php echo e($tarea->date); ?></b> a las: <b><?php echo e($tarea->time); ?></b></h6>
      </div>
      <div class="card-body">
        <h6><b> Descripción:</b></h6>
        <p class="card-text"><?php echo e($tarea->descripcion); ?></p>
        <p><b>  Tipo de archivo permitido: </b><span><?php echo e($tarea->tipo_arch); ?></span></p>
        <?php if(! $tarea->file==NULL): ?>
        <p class="d-inline"> <b> Archivo auxiliar: </b></p>
        <?php endif; ?>
        <a target="_blank" href="<?php echo e(asset("tareas/$tarea->file")); ?>"class="text-body"><?php echo e($tarea->file); ?></a>
      </div>
    </div>
  </div>
  <br>  
  
  <div class="container"> 
   <h3 class="text-left pb-2 pb-md-3">Entregas</h3>
   <table class="table table-hover">
     <thead>
       <tr>
         <th scope="col">Usuario</th>
         <th scope="col">Archivo</th>
         <th scope="col">Calificación</th>
       </tr>
     </thead>
     <tbody>
       <?php $__currentLoopData = $entregas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entrega): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <?php if($entrega->tarea_id == $tarea->id): ?>
       <tr>
         <th scope="row"><?php echo e($entrega->user->name); ?></th>
         <td><a target="_blank" href="<?php echo e(asset("entregas/$entrega->file")); ?>"><?php echo e($entrega->file); ?></a></td>
         <td>
           <form action="<?php echo e(route('entrega.update', $entrega->id)); ?>" method="POST">
            <?php echo method_field('PATCH'); ?>
            <?php echo csrf_field(); ?>
            <input type="number" min="0" max="10" name="grade" 
            <?php if(! $entrega->grade==NULL): ?>
            value="<?php echo e($entrega->grade); ?>" 
            <?php else: ?>
            value="0"
            <?php endif; ?>
            >
            <button type="submit" class="btn btn-primary btn-sm">Guardar</button>
          </form>
        </td>
      </tr>
      <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
</main> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\prueba2\resources\views/admin/tareas/show.blade.php ENDPATH**/ ?>