
<?php $__env->startSection('content'); ?>
<main class="main_reg">
    <div class="card titulo bienvenidos">
        <div class="container">
            <h2>Sube aquí tu archivo</h2>
        </div>
    </div>      
    <div class="container tareas p-3 p-md-5">
        <div class="form amarillo card text-black mb-3 tarea  mx-auto container" >
          <form action="<?php echo e(route('entrega.store')); ?>" method="POST" enctype="multipart/form-data" class="text-center">
            <?php echo csrf_field(); ?>
            <input type="text" class="d-none" name="tarea_id" value="<?php echo e($tarea->id); ?>">
            <input type="file" name="file">
            <br>
            <button type="submit" class="btn btn-w  mt-3">Guardar</button>
        </form>
    </div>
</div>    
</main> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\prueba2\resources\views/entregas/create.blade.php ENDPATH**/ ?>