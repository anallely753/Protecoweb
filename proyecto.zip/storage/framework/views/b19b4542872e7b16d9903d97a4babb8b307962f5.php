
<?php $__env->startSection('content'); ?>
<main>
	<div class="jumbotron jumb-usr">
		<div class="container amarillo p-3 text-center">
			<img src="<?php echo e(asset("img/users/$user->img")); ?>" alt="" class="show-user">
			<br><br>
			<h2><?php echo e($user->name); ?></h2>
			<h5><?php echo e($user->email); ?></h5>
		</div>
	</div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\prueba2\resources\views/admin/usuarios/show.blade.php ENDPATH**/ ?>