
<?php $__env->startSection('content'); ?>
<main class="main_grades">
	<div class="card titulo bienvenidos">
		<div class="container">
			<h2>Calificaciones</h2>
		</div>
	</div> 
	<div class="container mt-2 mt-md-3 grades">
		<table class="table table-hover mx-auto">
			<thead>
				<tr class="amarillo">
					
					<th scope="col" class="mr-3">Tarea</th>
					<th scope="col" class="pl-md-5 mr-md-5">Calificación</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $entregas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entrega): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($entrega->grade>6): ?>
				<p class="d-none"><?php echo e($color="text-success"); ?></p>	
				<?php endif; ?>
				
				<?php if($entrega->user->id==$user->id): ?>
				<?php if(! $entrega->grade==NULL): ?>
				<tr>
					
					<td class="pr-md-5 mr-md-5"><?php echo e($entrega->tarea->titulo); ?></td>
					<td class="text-center pl-md-5 mr-md-5 <?php echo e($color); ?>"><b><?php echo e($entrega->grade); ?></b></td>
				</tr>
				<?php endif; ?>
				<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
	
	
	
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\prueba2\resources\views/usuarios/grades.blade.php ENDPATH**/ ?>