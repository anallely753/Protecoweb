<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\laragon\www\prueba2\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>