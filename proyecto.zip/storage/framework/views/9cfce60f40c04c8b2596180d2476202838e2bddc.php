<?php $__env->startSection('content'); ?>
<main class="main_index">
  <div class="card titulo bienvenidos">
    <div class="container">
      <h1 class="d-none d-sm-block">Bienvenidos</h1>
      <h2>Curso Desarrollo Web</h2>
      <h3 class="d-none d-sm-block">Gen 40</h3>
      <?php if(Session::has('success')): ?>
      <div class="alert alert-success alert-dismissible fade show" role="alert">
       <h4><?php echo e(Session::get('success')); ?></h4>
       <button type="button" class="close" data-dismiss="alert" aria-label="Close">
         <span aria-hidden="true">&times;</span>
       </button>
     </div>
     <?php endif; ?>
   </div>

 </div>      
 <div class="container tareas">
  <h4 class="p-2 d-none d-sm-block">Tareas pendientes:</h4>
  <?php $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  
  <?php if($n>3): ?>
  <span class="d-none"><?php echo e($n=0); ?></span>
  <?php endif; ?>
  
  <p class="d-none"><?php echo e($bandera=0); ?></p>
  <?php $__currentLoopData = $entregas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entrega): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($entrega->tarea_id==$tarea->id): ?>
  <p class="d-none"><?php echo e($bandera=1); ?></p>
  <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php if($bandera==0): ?>

  <span class="d-none"> <?php echo e($a=$num[$n]); ?></span>
  <div class="card text-black mb-3 tarea <?php echo e($colores[$a]); ?>" >
    <div class="card-header">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12 col-sm-6 text-left">
            <h3 class="card-title"><?php echo e($tarea->titulo); ?></h3>
          </div>
          <div class="col-12 col-sm-3 text-left">
            <h6>Fecha de Entrega: <b><?php echo e($tarea->date); ?></b> 
             <h6>A las: <b><?php echo e($tarea->time); ?></b> hrs.</h6>
           </div>
           <div class="col-12 col-sm-3 text-left text-md-right">
            <a href="<?php echo e(route('entrega.show', $tarea->id)); ?>">
              <button type="button" class="btn bg-light" data-toggle="modal" data-target="#exampleModalCenter">
                Subir archivo
              </button>

            </a>
          </div>

        </div>
      </div>
    </div>
    <div class="card-body">
      <h6><b> Descripción:</b></h6>
      <p class="card-text"><?php echo e($tarea->descripcion); ?></p>
      <p><b>  Tipo de archivo permitido: </b><span><?php echo e($tarea->tipo_arch); ?></span></p>
      <?php if(! $tarea->file==NULL): ?>
      <p class="d-inline"> <b> Archivo auxiliar: </b></p>
      <?php endif; ?>
      <a target="_blank" href="<?php echo e(asset("tareas/$tarea->file")); ?>"class="text-body"><?php echo e($tarea->file); ?></a>
    </div>
    <span class="d-none"><?php echo e($n++); ?></span>
  </div>
  <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</main> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\prueba2\resources\views/home.blade.php ENDPATH**/ ?>