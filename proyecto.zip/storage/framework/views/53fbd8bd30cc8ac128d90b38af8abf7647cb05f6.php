
<?php $__env->startSection('content'); ?>
<main>
	<div class="jumbotron jumb-usr">
		<div class="container amarillo p-3 text-center">
			<img src="<?php echo e($user->img); ?>" alt="" class="show-user">
			<br><br>
			<h2><?php echo e($user->name); ?></h2>
			<h5><?php echo e($user->email); ?></h5>
		</div>
	</div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\prueba2\resources\views/user/show.blade.php ENDPATH**/ ?>