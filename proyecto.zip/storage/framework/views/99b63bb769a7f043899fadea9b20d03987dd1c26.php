
<?php $__env->startSection('content'); ?>
<main>
	<div class="container">
		<br>
		<h1 class="text-left">Usuarios	<a href="<?php echo e(route('adminusuarios.create')); ?>">
			 <button type="button" class="btn btn-success float-right">Agregar Usuario</button>
		</a></h1>
		<br>
		<table class="table table-hover">
		  <thead>
		    <tr>
		      <th scope="col">ID</th>
		      <th scope="col">Nombre</th>
		      <th scope="col">Email</th>
		      <th scope="col">Admin</th>
		      <th>Opciones</th>
		    </tr>
		  </thead>
		  <tbody>
		  	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		    <tr>
		      <th scope="row"><?php echo e($user->id); ?></th>
		      <td><?php echo e($user->name); ?></td>
		      <td><?php echo e($user->email); ?></td>
		      <td><?php echo e($user->admin); ?></td>		
		      <td>		      	      
		      	<form action="<?php echo e(route('adminusuarios.destroy', $user->id)); ?>" method="POST">
		      		<a href="<?php echo e(route('adminusuarios.show', $user->id)); ?>"><button type="button" class="btn btn-secondary bg-secondary">Ver</button></a>
		      		<a href="<?php echo e(route('adminusuarios.edit', $user->id)); ?>"><button type="button" class="btn btn-primary d-none d-sm-inline bg-primary">Editar</button></a>
		      		<?php echo csrf_field(); ?>
		      		<?php echo method_field('DELETE'); ?>
		      		<button type="submit" class="btn btn-danger d-none d-sm-inline bg-danger">Eliminar</button>
		      	</form>
		      
		      </td>       
		    </tr>
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		  </tbody>
		</table>
	</div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\prueba2\resources\views/admin/usuarios/index.blade.php ENDPATH**/ ?>