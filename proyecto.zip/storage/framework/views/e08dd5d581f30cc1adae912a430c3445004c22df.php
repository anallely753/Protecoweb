
<?php $__env->startSection('content'); ?>
<main class="main_regA">
	<div class="card titulo bienvenidos">
		<div class="container haztucuenta">
			<h3>Edita tu usuario</h3>
		</div>
	</div>      
	<!-- form -->
	<div class="form azul card text-black mb-3 tarea  mx-auto container" >
		<form class="text-white" method="POST" action="<?php echo e(route('adminusuarios.update',$user->id)); ?>">
			<?php echo method_field('PATCH'); ?>
			<?php echo csrf_field(); ?>
			<div class="form-group">
				<label for="name">Nombre</label>
				<input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>" required>
			</div>
			<div class="form-group">
				<label for="exampleInputEmail1">Email address</label>
				<input type="email" class="form-control" name="email" aria-describedby="emailHelp" value="<?php echo e($user->email); ?>" required>
			</div>
			<div class="form-group ml-3">
				    <input class="form-check-input" type="checkbox" name="admin"
					<?php if(  $user->admin == "1"): ?>
					checked
					<?php endif; ?> 
				    >

				<label class="form-check-label" for="remember"><small>Admin</small></label>
			</div>
			<br>
			<button type="submit" class="btn btn-w">Guardar</button>
		</form>
	</div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\prueba2\resources\views/admin/usuarios/edit.blade.php ENDPATH**/ ?>