
<?php $__env->startSection('content'); ?>
<main class="main_index">
  <div class="card titulo bienvenidos">
    <div class="container">
      <h2 class="text-left d-inline-block">Tareas</h2>
      <a href="<?php echo e(route('admintareas.create')); ?>">
        <button type="button" class="btn btn-success float-right">Agregar Tarea</button>
      </a>
    </div>
  </div><br>  
  <div class="container tareas tareas-admin">
    <?php $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($n>3): ?>
      <span class="d-none"><?php echo e($n=0); ?></span>
      <?php endif; ?>
    <span class="d-none"> <?php echo e($a=$num[$n]); ?></span>
    <div class="card text-black mb-3 tarea <?php echo e($colores[$a]); ?>" >
        <div class="card-header">
            <h2 class="card-title d-inline "><?php echo e($tarea->titulo); ?></h2>
            <form action="<?php echo e(route('admintareas.destroy', $tarea->id)); ?>" method="POST" >
              <a href="<?php echo e(route('admintareas.show', $tarea->id)); ?>"><button type="button" class="btn btn-light float-right">Ver</button></a>
              <a href="<?php echo e(route('admintareas.edit', $tarea->id)); ?>"><button type="button" class="btn btn-light float-right">Editar</button></a>
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <a><button type="submit" class="btn btn-light float-right">Eliminar</button></a>
            </form>
            <h6 >Fecha de Entrega: <b><?php echo e($tarea->date); ?></b> a las: <b><?php echo e($tarea->time); ?></b></h6>
        </div>
        <div class="card-body">
            <h6><b> Descripción:</b></h6>
            <p class="card-text"><?php echo e($tarea->descripcion); ?></p>
            <p><b>  Tipo de archivo permitido: </b><span><?php echo e($tarea->tipo_arch); ?></span></p>
            <?php if(! $tarea->file==NULL): ?>
            <p class="d-inline"> <b> Archivo auxiliar: </b></p>
            <?php endif; ?>
            <a target="_blank" href="<?php echo e(asset("tareas/$tarea->file")); ?>"class="text-body"><?php echo e($tarea->file); ?></a>
        </div>
    </div>
    
    <span class="d-none"><?php echo e($n++); ?></span>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</main> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\prueba2\resources\views/admin/tareas/index.blade.php ENDPATH**/ ?>