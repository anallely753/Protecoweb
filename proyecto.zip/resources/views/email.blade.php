<p>De: <b>{{ $name }}</b></p>
<p>Asunto: <b>{{ $subject }}</b></p>
<p>Mensaje:</p>
<p><b>{{ $user_message }}</b></p>
<p>Email: <b>{{ $email }}</b></p>
<p>Bye :)</p>
